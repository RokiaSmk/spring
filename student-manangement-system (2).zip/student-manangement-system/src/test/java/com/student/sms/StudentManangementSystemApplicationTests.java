package com.student.sms;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentManangementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
